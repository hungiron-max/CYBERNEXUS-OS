{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "fb2138665ad6b02a71c4faaa68eadd8030d9a8bbf815fcdb5b071476be12af61ee9fb57e199f3fc8bbeefaefed9dfcd6be772b92fe038cf9e2bb7b5bf8924b21",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "08cc515b7abf6570023847582715896c59dd82a8ff6a9bba74e32f98139a628c",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}