{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "173e81fd4481d9447ea136516da6c47a84d9f67f93d31fb07cd7e8fd87f0b5f470402e9c5db388852f05c3b1338f30cf104f7d9edabaf66d13da59ea3f94cbd7",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}