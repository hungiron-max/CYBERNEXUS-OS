{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "5b7c344e965b3e04bfd25ce15255997dbfd726bed319e1990dca51b6f5ee82e87592f1e4acb1688f4fb64a57cafa8f1aba4a7c3f37ec16df31da770e1a56c89b",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}