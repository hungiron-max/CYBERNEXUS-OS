/**
 * CyberNexus OS — Attendance Portal & Kiosk PIN Controller (HR-07)
 */
(function (global) {
    'use strict';

    const AttendanceKiosk = {
        mode: 'personal',
        camStream: null,

        init() {
            this.updateClock();
            setInterval(() => this.updateClock(), 1000);
            this.loadPersonalStatus();
            const pinEl = document.getElementById('att-kiosk-pin');
            if (pinEl) {
                pinEl.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') this.submitKioskPunch();
                });
            }
        },

        updateClock() {
            const el = document.getElementById('att-live-clock');
            if (!el) return;
            const now = new Date();
            el.textContent = now.toLocaleTimeString('vi-VN') + ' • ' + now.toLocaleDateString('vi-VN');
        },

        showBanner(msg, type = 'info') {
            const el = document.getElementById('att-banner');
            if (!el) return;
            const cls = type === 'success'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200'
                : (type === 'error' ? 'bg-rose-500/15 border-rose-500/40 text-rose-200' : 'bg-sky-500/15 border-sky-500/40 text-sky-200');
            el.className = `p-3.5 rounded-xl border text-xs font-semibold ${cls}`;
            el.textContent = msg;
            el.classList.remove('hidden');
        },

        switchMode(nextMode) {
            this.mode = nextMode === 'kiosk' ? 'kiosk' : 'personal';
            document.getElementById('att-panel-personal')?.classList.toggle('hidden', this.mode !== 'personal');
            document.getElementById('att-panel-kiosk')?.classList.toggle('hidden', this.mode !== 'kiosk');
            const pBtn = document.getElementById('att-mode-personal-btn');
            const kBtn = document.getElementById('att-mode-kiosk-btn');
            if (pBtn) pBtn.className = this.mode === 'personal'
                ? 'px-4 py-2 rounded-xl text-xs font-bold bg-sky-500/25 text-sky-200 border border-sky-400/40'
                : 'px-4 py-2 rounded-xl text-xs font-bold text-slate-300 hover:text-white bg-slate-900 border border-white/10';
            if (kBtn) kBtn.className = this.mode === 'kiosk'
                ? 'px-4 py-2 rounded-xl text-xs font-bold bg-sky-500/25 text-sky-200 border border-sky-400/40'
                : 'px-4 py-2 rounded-xl text-xs font-bold text-slate-300 hover:text-white bg-slate-900 border border-white/10';
        },

        authHeaders() {
            const token = localStorage.getItem('pos_token') || '';
            return {
                'Content-Type': 'application/json',
                ...(token ? { 'Authorization': 'Bearer ' + token } : {})
            };
        },

        async loadPersonalStatus() {
            const loginBox = document.getElementById('att-login-box');
            const profBox = document.getElementById('att-profile-box');
            try {
                const res = await fetch('/api/operations.php?action=my_attendance_status', { headers: this.authHeaders() });
                const data = await res.json();
                if (!res.ok || !data.success) {
                    loginBox?.classList.remove('hidden');
                    profBox?.classList.add('hidden');
                    return;
                }
                loginBox?.classList.add('hidden');
                profBox?.classList.remove('hidden');
                const u = data.user || {};
                const fn = document.getElementById('att-user-fullname');
                const rl = document.getElementById('att-user-role');
                if (fn) fn.textContent = u.fullname || u.username || '';
                if (rl) rl.textContent = `Vai trò: ${u.role || 'staff'} • Hôm nay: ${data.today || ''}`;

                const shiftEl = document.getElementById('att-active-shift-card');
                const sh = data.active_shift;
                if (shiftEl) {
                    if (sh && sh.id) {
                        shiftEl.innerHTML = `<span class="text-emerald-300 font-bold">🟢 Đang trong ca từ ${(global.escapeHtml ? global.escapeHtml(sh.check_in_time || '') : (sh.check_in_time || ''))}</span> <span class="text-slate-400">(${sh.source || 'auto'})</span>`;
                    } else {
                        shiftEl.innerHTML = '<span class="text-slate-400">Chưa check-in ca làm việc hôm nay.</span>';
                    }
                }

                const histEl = document.getElementById('att-personal-history');
                if (histEl) {
                    const rows = data.recent_records || [];
                    histEl.innerHTML = rows.length ? rows.map(r => `
                        <tr>
                            <td class="py-1.5 font-mono">${r.work_date || ''}</td>
                            <td class="py-1.5 font-mono text-sky-300">${(r.check_in_time || '').slice(11, 16)}</td>
                            <td class="py-1.5 font-mono text-amber-300">${r.check_out_time ? r.check_out_time.slice(11, 16) : 'Đang ca'}</td>
                            <td class="py-1.5">${r.source || 'auto'}</td>
                            <td class="py-1.5 text-right font-mono font-bold">${Number(r.work_hours || 0).toFixed(2)}h</td>
                        </tr>
                    `).join('') : '<tr><td colspan="5" class="py-4 text-center text-slate-500">Chưa có dữ liệu chấm công</td></tr>';
                }
            } catch (e) {
                loginBox?.classList.remove('hidden');
                profBox?.classList.add('hidden');
            }
        },

        async personalLogin() {
            const username = (document.getElementById('att-login-user')?.value || '').trim();
            const password = document.getElementById('att-login-pass')?.value || '';
            try {
                const res = await fetch('/api/auth.php?action=login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                });
                const data = await res.json();
                if (!data.success || !data.token) {
                    this.showBanner(data.message || 'Đăng nhập thất bại!', 'error');
                    return;
                }
                localStorage.setItem('pos_token', data.token);
                this.showBanner('Đăng nhập thành công!', 'success');
                await this.loadPersonalStatus();
            } catch (e) {
                this.showBanner('Lỗi kết nối khi đăng nhập', 'error');
            }
        },

        personalLogout() {
            localStorage.removeItem('pos_token');
            document.getElementById('att-login-box')?.classList.remove('hidden');
            document.getElementById('att-profile-box')?.classList.add('hidden');
        },

        captureSelfieBase64() {
            const video = document.getElementById('att-webcam-video');
            const canvas = document.getElementById('att-webcam-canvas');
            if (!video || !canvas || !this.camStream || video.readyState < 2) return '';
            canvas.width = video.videoWidth || 320;
            canvas.height = video.videoHeight || 240;
            const ctx = canvas.getContext('2d');
            if (!ctx) return '';
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            return canvas.toDataURL('image/png');
        },

        async toggleCamera() {
            const video = document.getElementById('att-webcam-video');
            const ph = document.getElementById('att-webcam-placeholder');
            const btn = document.getElementById('btn-toggle-cam');
            if (this.camStream) {
                this.camStream.getTracks().forEach(t => t.stop());
                this.camStream = null;
                if (video) video.classList.add('hidden');
                if (ph) ph.classList.remove('hidden');
                if (btn) btn.textContent = 'Bật Camera';
                return;
            }
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                this.showBanner('Trình duyệt không hỗ trợ webcam ở giao thức hiện tại.', 'error');
                return;
            }
            try {
                this.camStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 320, height: 240 } });
                if (video) {
                    video.srcObject = this.camStream;
                    video.classList.remove('hidden');
                }
                if (ph) ph.classList.add('hidden');
                if (btn) btn.textContent = 'Tắt Camera';
            } catch (e) {
                this.showBanner('Không thể truy cập camera: ' + (e.message || e), 'error');
            }
        },

        async submitWebPunch(actionName) {
            const note = (document.getElementById('att-personal-note')?.value || '').trim();
            try {
                const res = await fetch(`/api/operations.php?action=${actionName}`, {
                    method: 'POST',
                    headers: this.authHeaders(),
                    body: JSON.stringify({ note })
                });
                const data = await res.json();
                this.showBanner(data.message || (data.success ? 'Chấm công thành công!' : 'Lỗi chấm công'), data.success ? 'success' : 'error');
                await this.loadPersonalStatus();
            } catch (e) {
                this.showBanner('Lỗi kết nối khi chấm công', 'error');
            }
        },

        appendPin(ch) {
            const inp = document.getElementById('att-kiosk-pin');
            if (inp && inp.value.length < 8) inp.value += ch;
        },

        clearPin() {
            const inp = document.getElementById('att-kiosk-pin');
            if (inp) inp.value = '';
        },

        async submitKioskPunch() {
            const pin = (document.getElementById('att-kiosk-pin')?.value || '').trim();
            const mode = document.getElementById('att-kiosk-mode')?.value || 'auto';
            const photo = this.captureSelfieBase64();
            if (!pin) {
                this.showBanner('Vui lòng nhập mã PIN 6 số!', 'error');
                return;
            }
            try {
                const res = await fetch('/api/operations.php?action=kiosk_punch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ pin_code: pin, mode, photo_base64: photo })
                });
                const data = await res.json();
                this.showBanner(data.message || (data.success ? 'Quẹt công thành công!' : 'Lỗi Kiosk'), data.success ? 'success' : 'error');
                if (data.success) this.clearPin();
            } catch (e) {
                this.showBanner('Lỗi kết nối Kiosk', 'error');
            }
        }
    };

    global.AttendanceKiosk = AttendanceKiosk;
    document.addEventListener('DOMContentLoaded', () => AttendanceKiosk.init());
})(window);
