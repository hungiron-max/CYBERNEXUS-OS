{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "cf7e70b591b17778187dc620b72977c0e05262f17752a749097acd8193309bc1210e003970f8d11039a7408065528ddf34aa4db9ef57fe0e598388d6d825ccc8",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "a83a3e42a5d3b6424ce0701527c3a19c95f731de71bbe51ebf3528005dfb9637",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}