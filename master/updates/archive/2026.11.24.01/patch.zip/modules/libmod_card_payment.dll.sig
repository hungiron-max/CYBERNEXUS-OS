{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "e02b449fdd0851c0c377c0c813664c0a199504f6620e50f0f1fa5f3e11de8de371c653204d88a9db9f0001c0668c6e1980199ce146db9e391a5d22e22dc8ddc7",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}