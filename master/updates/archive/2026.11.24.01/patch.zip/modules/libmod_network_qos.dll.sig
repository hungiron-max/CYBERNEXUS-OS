{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "632476973deaea2869c6234bb6b4e63bfe906f6cf84220d99379a4b723e34890beced3de74b5c0d819ed0b5ff326ebf28af16a8ec9c24fa15a82597eeff66fac",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "4f83c975976c253103647c9fd2553b396439609675c18795a1ad437cff2a82d6",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}