{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "a1d1cd5c1fda776449cefceb1d3d263036636b6e756953ecd2395710590aa76ad6c56ce79ccfea9bdf99e4bb5922737e0295d91e45eae2b9f87d396f0d13c5eb",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}