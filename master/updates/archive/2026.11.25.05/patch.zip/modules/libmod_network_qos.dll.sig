{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "f70b7eaf375733f1393e511545fdc2131a64e093fce170d200ff30658ad3079e7362b03778dbf65a51290f8690de80c238d8b749e9603a08051f28c6dd79dbed",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}