{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "2c17c4b026fa827fd310cb1b44e0085ea905994ef4f41273557e0e922df62938f9dfc0b216f5a6e7d8c1fa6c1e482f3cc8b3a3a7afaf4b99269e60e4555d6d73",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}