{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "029424b2965eeacb28fb01c85c35c15fbb61ef5499ef607b0b6e253a6a9b4ea13e6a098d234f8d443257bf703a7e8e30c5d632046ae9ebabafd50f6ca08f4365",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}