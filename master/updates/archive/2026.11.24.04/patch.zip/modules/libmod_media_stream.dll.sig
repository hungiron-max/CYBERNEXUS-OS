{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "519cb3d392a7f2f0f99d2fda30ce32da82818d6caf0526e2934c4ca3303ff0efceebf57bbd40861951b24c251e18e918cab1c5c7e90d1a2410492ffa04ee3b17",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "cb5c4945c93269853bc52e4ba9f2436486c28744dd3bc8e82c7b8de2944c6661",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}