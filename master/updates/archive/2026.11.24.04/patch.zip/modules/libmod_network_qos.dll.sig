{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "a42ead61c912200301fab814dfbefa758b9f9dfc8af86061136698bdc2625a86eefe7391599c3abba9ddbe8ede7f79f346e5da91310cca044365179ac50a7b28",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}