{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "d3dc1339cdaf6233ddfcd8b3242c1f9752bc6470f7d4b4b44f0bfee0d895bd7e74ce6b3babf74de4cf2dbc2419cb3602617897384abde667f25ecbdd1db8717a",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "353c8be0c2d7f83fac486ef7cb3539afd002810d0ef408b2a4579980d7f07344",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}