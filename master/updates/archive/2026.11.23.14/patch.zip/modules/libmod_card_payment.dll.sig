{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "bf688caedbd1b441a12f2350a9c345c272ebe13a88253317e7d0d19f6a90f9ae390a4954878e2cae4dbfe0b72a929bd408a746688343e18c58764bdede7afb6e",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}