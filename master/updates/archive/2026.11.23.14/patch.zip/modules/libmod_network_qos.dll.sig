{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "c67be0fa80f13a0a36f9817e396a7fd3a012e865e9bf147ba9e144fb885ffb505ac14a3adc6344e01e6e29131d08b0fd5b62f5d7099c57348c21c182ce9ea0dc",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "4f83c975976c253103647c9fd2553b396439609675c18795a1ad437cff2a82d6",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}