{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "f245a36eed41a0273b7f42620910b5d90709dd72e98939a4e6b5008172c9899aecbe948eae2f3a90d6190c8a8fd39ae2dee481e281b1b9a3c571edc64c926ec1",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1cb6823252763d48537598a9177ab137b29331ff3b992bb91e61eb8595708db",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}