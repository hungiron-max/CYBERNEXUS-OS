{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "71098981f6735ee386f9ee42fc8543fc048d57e068e7657a6ed4a2314faeaf859bfac69f9ceee2555d805eedf47822bfe5d33477d86526c0e2420543b1ab7009",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}