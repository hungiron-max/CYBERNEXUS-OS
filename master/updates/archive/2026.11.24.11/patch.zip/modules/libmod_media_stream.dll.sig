{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "bd7996d479e686b3e20a5f9bbda489e96527a0073382e9824191aea7d64f0f36f7aaeb7638428ed093cb675f0ff07a2485a2d648241d66c37917001998ceb1f4",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "88d331ab72d0e54ad631215481c3e1b0344bfe6f47bafdb655d9b2663206b959",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}