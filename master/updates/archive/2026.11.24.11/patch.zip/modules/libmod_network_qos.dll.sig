{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "bfe92412876717d8ff077950744667e4f6ee0b6c6f43482ec2f531f5f74f1d29a38dc7f2945b73976567079eee860527e5292546a7745ccd334210edc5ad5539",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}