{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "95f82795f2b67a313c1d9249818d7ad1c83af984f52e9e26c9607549c506250d26f419ff9bfd3ad0a4d9f4f8bd5509f0de2450c02707b1306748117a49a982c7",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "db3f39f87548868114d5fa87ef84e6707db7aeadccaa92f18b064655deae8924",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}