{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "fb2a81d0248ce456f88a83c1fb8066b2f640d0fa3bbc05cadace1235ff546e4324329c5737cd342eb17ce4b520a131abf1e334c9973c00425e4b7bcdab90740c",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "97be79a40534d763c633e084a586b81c06a224821333335f932b28e6102dbce5",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}