{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "4e0dec71ece4fb80e696f9ffce3f2d7f1cc7c197ac14e416bc03e38410516fdeee24cf144d586c1384650b97903eb998b247ebe7a45ae57028d2a4efaffc7ace",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}