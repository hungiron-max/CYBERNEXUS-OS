{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "41696a68a343b8e63666a3443bc16c375135ee1c96387ae95c824f1631990e6e97b3ae21e86f7176e37d00a90df6e3f6063c610fab36594c69f22247b01cf0ea",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "88d331ab72d0e54ad631215481c3e1b0344bfe6f47bafdb655d9b2663206b959",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}