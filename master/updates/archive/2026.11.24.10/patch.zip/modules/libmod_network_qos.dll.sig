{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "f902e59b35274edd244ffb041443f1d6ba6b5f03cf081a4b4f61262613628ed225c475c42d44b7435077c8cc461df71fdf3f1ba6b11311c022c9f5bfa1121114",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}