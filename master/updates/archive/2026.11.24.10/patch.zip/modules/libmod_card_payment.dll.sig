{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "a1224c5ae67198bfe4c2c2df4c529f0e1f7dbd5a0d88c642808d53987c37c4cd9ed9a22a870055086c4bfdbcc8cf4fd4416809633a7880d01fcd2093addf3751",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}