{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "38613bd99c6df003faa5c018432d86d8e0bcc4b8fd798d79e90f555c79d5fdea944e9e75b62fe6dbdf7e622e8148b6b9d12201c3dc3bc2348f3335969ba4b79a",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}