{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "60d458aba267b72da9bfcb1961aacf7284641f80508551edd90ddeb63e5ea81dadd1b3c91b595ef9a084c00779c1f2420e8fe3c450a1b792daa1720498717c7b",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "b45f72a0c89e8cd07ea1116134bf7cd2da59d92913de61185e8a20685107bb65",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}