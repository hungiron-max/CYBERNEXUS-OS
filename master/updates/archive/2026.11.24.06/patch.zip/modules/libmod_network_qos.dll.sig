{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "e4c57c55b7a1abd023a765159ce7332cfa36929f637c30e5af2597c5859ca781ee5d9fe0830d1ff5716abb1c11c8da14d61d3b4bd0c7f615647349efcc6f6076",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}