{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "7a20204855f0d1e4e7cb3a208d832b54dd94b22b6cd18da3b9e39c0f15bede2575c3f5390fb066ee3c9f4f87a73f3bd899ef5c5e955f52e618ff9fe93c19a38c",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}