{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "eca9ca31847f19cdacaca27c1c16c2901dd408be46befc082caabfa2509409135b4cb6de5c14d4e70c4f6344dbba1949819c814713ed8aba0219e5daadc79421",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}