{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "e67b778a93053b508e5a2312b53feacd55564c372d3b874d039928bad404c19b87f72a7e92dc1f83e56bb575d613011f390c2d225d253233b5fde92db10608b5",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "cb5c4945c93269853bc52e4ba9f2436486c28744dd3bc8e82c7b8de2944c6661",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}