{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "fca1ee39f362b64d9ae80775ee957112e9e7a2e7a26d70bad5498fe409f2817eb5598ac1a5ebd372319c909eefb315bc98a7ed596e406aff4c28b1ba04c2a6d7",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "97be79a40534d763c633e084a586b81c06a224821333335f932b28e6102dbce5",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}