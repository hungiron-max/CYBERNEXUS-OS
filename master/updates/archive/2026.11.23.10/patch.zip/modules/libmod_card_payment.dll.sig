{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "7f165114f1b5c4c67b8b23203933e90a0cff06b2207abf9c34ad1d1b951fbb4a77f314f6c6e6108a7c346631485aa0d43e4c00e56f74e021bc5ecfad5e9cfc38",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}