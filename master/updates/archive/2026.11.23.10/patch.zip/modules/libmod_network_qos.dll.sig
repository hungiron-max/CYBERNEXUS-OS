{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "65e2367b89cc009ca4e23a5813f3dbb8646be95de7afd82995a6c866a096971e869d9d50071b8f4a9f6007b7f4ad966b71903a770975399ece98a2062655108c",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "dba8eb6d58a2f6b6ef65c4a382cdf5a4ec067c4b2afcb6d45c9fadf04709b591",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}