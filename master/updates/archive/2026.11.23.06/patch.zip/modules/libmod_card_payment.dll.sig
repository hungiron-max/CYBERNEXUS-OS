{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "1a2538ade7f5280136d6ebd2754c09050e8de0ae16f4e32764af5f0af4d42f5c4a2e8bf960385c301741071ad85c698d20ce415961d72420464825b1945a7d40",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}