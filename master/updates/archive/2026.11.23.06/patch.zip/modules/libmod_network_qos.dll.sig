{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "40191f3dd06be2ba8c64d5d0e187a134603406a7eca8ac7fa50d38331f6c28ee2326fbc4a41b0f5ca2443bc87d3b7407cbdce7e64e7ca87c028877b405492760",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c65f03a5b517baf9f0a311c781362b7e1213e0d1381a2e44ace0e58f1a3aff3f",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}