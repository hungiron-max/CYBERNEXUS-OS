{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "b654b945d5d7d7d548af13a8d19c481ea226626b41ed426dfb19de5fb8ba8bd0f39103468639e5bccff1bc652b10b1153c149db59b5259bc457f553ef764de64",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "97be79a40534d763c633e084a586b81c06a224821333335f932b28e6102dbce5",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}