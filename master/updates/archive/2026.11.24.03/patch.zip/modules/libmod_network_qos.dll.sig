{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "9d9986922203c4977541f213c3420309d4e926e0a10f2a9e5a35ea590902a9f73be4e17825208cbfd83dc94b41053cd85bd7f7983c043135865e731d1d44261e",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "4f83c975976c253103647c9fd2553b396439609675c18795a1ad437cff2a82d6",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}