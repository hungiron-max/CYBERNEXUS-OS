{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "5308a49eacf742af0ded17a0027a971247c3bcc1d8706d0ba7feefed2d299572ada511b5a0373777a92ce872e7968391b4f127ef749267d2fc5de84d5e4600b0",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "a83a3e42a5d3b6424ce0701527c3a19c95f731de71bbe51ebf3528005dfb9637",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}