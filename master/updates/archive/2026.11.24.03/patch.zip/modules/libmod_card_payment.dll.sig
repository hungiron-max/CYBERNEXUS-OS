{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "d077cfbce7dce8b98ebb91ae3277762f3f0888afac54f7413c9879dc6a5bf1dc53e411395ed454a7ad0ff2ffec755cddd797bca9f8a5bf0628562d58fe1c794c",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}