{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "3621a9c671b73be0728ec8c5ccff1cbd31cc241abfa28e22a6fc7f14a57eced7664a2f675649d3d12ead3ac87f98f51e369c0db63410989021338e9591299a0f",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "353c8be0c2d7f83fac486ef7cb3539afd002810d0ef408b2a4579980d7f07344",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}