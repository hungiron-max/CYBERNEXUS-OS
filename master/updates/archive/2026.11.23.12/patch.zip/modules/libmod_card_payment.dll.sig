{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "96a771e2698da087eefe2fc4d38f2e17434259e090b04d1df9dd2aa6113a04ba458ee9dbd225f98adfd20eb1814ee7e050c3314e262f1156938577ea35cd1f5b",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}