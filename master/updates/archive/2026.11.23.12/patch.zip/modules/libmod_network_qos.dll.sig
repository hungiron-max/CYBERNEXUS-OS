{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "798870d726ab7e568637010edb3969127da3b4dd6149444662119299ffab4589b8bedf3b8d76ef183fb3032775935963bb67a3cf2f588e6d0a2439897303053a",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "d83be5de9a25ebae43323dd795223e8010a0208edeedc33c57690c8c941777ee",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}