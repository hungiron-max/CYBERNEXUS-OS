{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "988faa97e1eb24b07b28af817338bbb724db5a8d59767e93ccfb038ff295f3d39bd5294efd8554e8e04228b1bacda19296be37b965ba404bfd831610f1e189e5",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}