{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "96192015a81064d8b4e9828d61df8efe47bee1700bab5b2e92b9f348df665708c522025d4c529413c8c429faf2eb99ce3003adab05b597c37cc4a7579733ecec",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}