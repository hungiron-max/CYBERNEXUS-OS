{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "ca3b3872653c095d67b1c1488d62d63cebd86c1c2a8743cbd3cca1d7ac31dd9c7ead2c0394a133c72dda4f2070e9cf7e21a95bfd39238c4ba6df4f7933708fe2",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}