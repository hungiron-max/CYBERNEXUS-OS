/**
 * CyberNexus OS — Shared Client Security Utilities (XSS Protection & Safe Diagnostics)
 */
(function (global) {
    'use strict';

    const HTML_ESCAPE_MAP = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
        '`': '&#96;'
    };

    function escapeHtml(val) {
        if (val === null || val === undefined) return '';
        return String(val).replace(/[&<>"'`]/g, function (ch) {
            return HTML_ESCAPE_MAP[ch];
        });
    }

    function escapeJsAttr(val) {
        if (val === null || val === undefined) return '';
        return String(val)
            .replace(/\\/g, '\\\\')
            .replace(/'/g, "\\'")
            .replace(/\r/g, '\\r')
            .replace(/\n/g, '\\n')
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '\\x3C')
            .replace(/>/g, '\\x3E')
            .replace(/`/g, '\\x60');
    }

    function safeUrl(url) {
        if (!url) return '';
        const s = String(url).trim();
        if (/^(javascript|data:text\/html|vbscript):/i.test(s)) {
            return '#';
        }
        return s;
    }

    const _errThrottle = {};
    function logSilentError(context, err) {
        try {
            const key = String(context || 'unknown');
            const now = Date.now();
            if (!_errThrottle[key] || now - _errThrottle[key] > 30000) {
                _errThrottle[key] = now;
                if (global.console && typeof global.console.debug === 'function') {
                    global.console.debug('[CyberNexus]', key, err && err.message ? err.message : err);
                }
            }
        } catch (ignored) {
            void ignored;
        }
    }

    const api = {
        escapeHtml: escapeHtml,
        escapeJsAttr: escapeJsAttr,
        safeAttr: escapeHtml,
        safeUrl: safeUrl,
        logSilentError: logSilentError
    };

    global.CyberSecurity = api;
    global.CyberNexusSec = api;
    if (typeof global.escapeHtml !== 'function') {
        global.escapeHtml = escapeHtml;
    }
    if (typeof global.escapeJsAttr !== 'function') {
        global.escapeJsAttr = escapeJsAttr;
    }
})(window);
