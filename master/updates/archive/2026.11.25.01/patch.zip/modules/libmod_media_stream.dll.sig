{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "79cf369f69a8a2f05cb1bc5cbc0cf024b69a385e565a10539dc52c40ac3c794d73cf66b76f1f61c07a8d19b2b2a1d3dbcb7efd1c2f5f3efb45f1d07df04826b4",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}