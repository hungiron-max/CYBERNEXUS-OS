{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "5b21e5c0c216cf0b7229702f22467134a917807e218cc5e459b57c3c5fa3b887dbf30e164d0342cbc05c4462b61d8c733012600008c60eba2e5329b970b2c6a9",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}