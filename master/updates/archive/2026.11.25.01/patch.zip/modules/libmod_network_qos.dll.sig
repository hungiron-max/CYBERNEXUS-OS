{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "0464412511ed2a88e9bc6cac277be2de8194c75cf67132b104686b759a24d7ef3032b15d5a34eef73d8cea16851c3f0eaa218391f90afba214d6a2806bef8479",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}