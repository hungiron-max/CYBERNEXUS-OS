{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "159c7739f61236b8960e832bf50246e066e83c653941f05dbc57dbce408b13772f2e80914b84acefb126bed032e499512ab133a3ba8b96f379ee7c2d63d39685",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}