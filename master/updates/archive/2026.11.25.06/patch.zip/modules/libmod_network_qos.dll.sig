{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "0305a1b89fdfd345a451198f517622a09864c1ed1c9e7a4f59a285bec57703bb037dd7eb2931688af7f12c72d2eaa01a2b40206915c6bc94bc601d8ccd8f1fee",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}