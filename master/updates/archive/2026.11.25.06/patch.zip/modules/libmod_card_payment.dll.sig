{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "76c8c494d1925069f1db5e6d6022e77a62ac56b24d8a2db439d7f96026537944a9848a03884d6dd8ffbcf2ce33934138b7b061a0ca440e5ee5458e724abe12fd",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}