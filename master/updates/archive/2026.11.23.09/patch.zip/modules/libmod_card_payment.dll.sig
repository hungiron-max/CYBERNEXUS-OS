{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "121e3f1d9e5e1a27cc3cada629fea9ff9a5500e83aa996d01a9ff4bd2e55fe92cc0ae388a87f86964e4721671591d2b6254f1ea1e303e82f6fe37795a83eadf4",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}