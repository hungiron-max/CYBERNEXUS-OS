{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "a9d14eec08c5dd8f51c3152dd429cd54c827981b0a700f0536a9bd0f2b716e9810e2b0f185093c8d5d45808f2a8e5dd5afc72a3e8fe6b4d0353b60cfcf41a4fe",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "97be79a40534d763c633e084a586b81c06a224821333335f932b28e6102dbce5",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}