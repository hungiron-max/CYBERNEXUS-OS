{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "abaf4f9ed71c33e173c6039514bcbeb1e572fb18a525a79cccde3b97c7f1ecc8ae598f6721cdf38cc3a71a16874473a8fe31c250f6c13a4f7b3c47bffdaec634",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "e2aa8db5d3e9b749e5f3e278525688a4241fd54c06bcf18c96f18302c79b7beb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}