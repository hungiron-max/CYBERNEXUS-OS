(function () {
    const FALLBACK_BRAND = {
        store_name: 'CyberNexus POS',
        store_wifi: '',
        store_wifi_ssid: '',
        store_hotline: '',
        store_address: ''
    };

    window.CN_STORE_BRAND = Object.assign({}, FALLBACK_BRAND);

    function applyStoreBrand(brand) {
        const name = (brand && brand.store_name) ? String(brand.store_name).trim() : FALLBACK_BRAND.store_name;
        const wifiSsid = (brand && (brand.store_wifi_ssid || brand.store_wifi)) ? String(brand.store_wifi_ssid || brand.store_wifi).trim() : '';
        window.CN_STORE_BRAND = Object.assign({}, FALLBACK_BRAND, brand, { store_name: name });

        document.querySelectorAll('[data-store-name]').forEach(el => {
            el.textContent = name;
        });
        document.querySelectorAll('[data-store-wifi]').forEach(el => {
            if (wifiSsid) el.textContent = wifiSsid;
        });

        const titleEl = document.querySelector('title');
        if (titleEl) {
            const suffix = titleEl.getAttribute('data-title-suffix');
            if (suffix) {
                document.title = `${name} - ${suffix}`;
            } else if (/CyberNexus POS|GÓC PHỐ|Góc Phố/i.test(document.title)) {
                document.title = document.title.replace(/GÓC PHỐ COFFEE & TEA|Góc Phố Coffee & Tea|CyberNexus POS/gi, name);
            }
        }

        const standeeTitle = document.getElementById('standee-store-title');
        if (standeeTitle) standeeTitle.textContent = name.toUpperCase();
    }

    window.getStoreBrandName = function () {
        return (window.CN_STORE_BRAND && window.CN_STORE_BRAND.store_name) || FALLBACK_BRAND.store_name;
    };

    window.applyStoreBrand = applyStoreBrand;

    function applyStoreTheme(theme) {
        if (!theme || typeof theme !== 'object' || (!theme.dark && !theme.light && !theme.primary)) {
            document.documentElement.removeAttribute('data-custom-theme');
            return;
        }
        const r = document.documentElement;
        const d = theme.dark || theme;
        const l = theme.light || {};
        r.setAttribute('data-custom-theme', '1');
        r.style.setProperty('--cn-primary', d.primary || '#38bdf8');
        r.style.setProperty('--cn-accent', d.accent || '#8b5cf6');
        r.style.setProperty('--cn-bg-start', d.bg_start || '#070d1b');
        r.style.setProperty('--cn-bg-end', d.bg_end || '#0f172a');
        r.style.setProperty('--cn-card-bg', d.card_bg || 'rgba(15, 23, 42, 0.78)');
        r.style.setProperty('--cn-card-border', d.card_border || 'rgba(56, 189, 248, 0.25)');
        r.style.setProperty('--cn-text', d.text || '#f1f5f9');
        if (l.primary) r.style.setProperty('--cn-light-primary', l.primary);
        if (l.accent) r.style.setProperty('--cn-light-accent', l.accent);
        if (l.bg_start) r.style.setProperty('--cn-light-bg-start', l.bg_start);
        if (l.bg_end) r.style.setProperty('--cn-light-bg-end', l.bg_end);
        if (l.card_bg) r.style.setProperty('--cn-light-card-bg', l.card_bg);
        if (l.card_border) r.style.setProperty('--cn-light-card-border', l.card_border);
        if (l.text) r.style.setProperty('--cn-light-text', l.text);
        r.style.setProperty('--cn-radius', (Number(theme.radius) || 16) + 'px');
        r.style.setProperty('--cn-blur', (Number(theme.blur) || 16) + 'px');
        if (theme.font) r.style.setProperty('--cn-font', theme.font);
        if (theme.slogan) {
            document.querySelectorAll('[data-store-slogan]').forEach(el => { el.textContent = theme.slogan; });
        }
    }
    window.applyStoreTheme = applyStoreTheme;

    window.addEventListener('message', (ev) => {
        if (ev && ev.data && ev.data.type === 'CN_THEME_PREVIEW') {
            applyStoreTheme(ev.data.theme);
            if (ev.data.store_name) applyStoreBrand({ store_name: ev.data.store_name });
        }
    });

    async function loadStoreBrand() {
        try {
            const cached = sessionStorage.getItem('cn_store_brand');
            if (cached) {
                applyStoreBrand(JSON.parse(cached));
            }
        } catch (e) {}

        try {
            const res = await fetch('/api/settings.php', { cache: 'no-store' });
            const json = await res.json();
            const d = (json && json.data) ? json.data : json;
            if (d && d.ota_applied_version) {
                const page = (window.location.pathname || '').toLowerCase();
                const isPublicPage = page.endsWith('/login.html') || page.endsWith('/customer.html') || page.endsWith('/wifi.html');
                const prevOta = localStorage.getItem('cnx_session_ota_ver');
                if (!isPublicPage && localStorage.getItem('pos_token')) {
                    if (prevOta && prevOta !== d.ota_applied_version) {
                        localStorage.removeItem('pos_token');
                        localStorage.removeItem('pos_user');
                        localStorage.setItem('cnx_session_ota_ver', d.ota_applied_version);
                        window.location.href = 'login.html?reason=updated';
                        return;
                    }
                    if (!prevOta) localStorage.setItem('cnx_session_ota_ver', d.ota_applied_version);
                } else if (isPublicPage) {
                    localStorage.setItem('cnx_session_ota_ver', d.ota_applied_version);
                }
            }
            if (d && d.theme_json) {
                try {
                    const tObj = typeof d.theme_json === 'string' ? JSON.parse(d.theme_json) : d.theme_json;
                    applyStoreTheme(tObj);
                    sessionStorage.setItem('cn_store_theme', JSON.stringify(tObj));
                } catch (e) {}
            } else {
                try {
                    const cachedTheme = sessionStorage.getItem('cn_store_theme');
                    if (cachedTheme) applyStoreTheme(JSON.parse(cachedTheme));
                } catch (e) {}
            }
            if (d && d.store_name) {
                applyStoreBrand(d);
                try {
                    sessionStorage.setItem('cn_store_brand', JSON.stringify({
                        store_name: d.store_name,
                        store_wifi: d.store_wifi || '',
                        store_wifi_ssid: d.store_wifi_ssid || '',
                        store_hotline: d.store_hotline || '',
                        store_address: d.store_address || ''
                    }));
                } catch (e) {}
            }
        } catch (e) {}

        try {
            const lRes = await fetch('/api/license.php?action=status', { cache: 'no-store' });
            const lJson = await lRes.json();
            if (lJson && lJson.success && lJson.data) {
                const mods = Array.isArray(lJson.data.modules) ? lJson.data.modules : [];
                const blocked = Array.isArray(lJson.data.blocked_modules) ? lJson.data.blocked_modules : [];
                const mediaAllowed = (mods.includes('mod_media_stream') || mods.includes('media_stream'))
                    && !blocked.includes('mod_media_stream') && !blocked.includes('media_stream');
                if (!mediaAllowed) {
                    ['pos-jukebox-pill', 'admin-jukebox-pill', 'customer-jukebox-bar'].forEach(id => {
                        const el = document.getElementById(id);
                        if (el) el.style.display = 'none';
                    });
                }
            }
        } catch (e) {}
    }

    function showInPageNotice(msg, type) {
        const text = String(msg || '').trim();
        if (!text) return;
        const lower = text.toLowerCase();
        const kind = type || (
            /(lỗi|thất bại|không thể|sai|chưa có|vui lòng|thiếu|hết|cấm|từ chối|invalid|error)/i.test(lower)
                ? (/vui lòng|chưa|thiếu|cảnh báo/i.test(lower) ? 'warn' : 'error')
                : (/thành công|đã |hoàn tất|ok/i.test(lower) ? 'success' : 'info')
        );
        const palette = {
            success: { border: 'rgba(16,185,129,0.55)', icon: '✓', color: '#34d399' },
            warn:    { border: 'rgba(245,158,11,0.55)', icon: '!', color: '#fbbf24' },
            error:   { border: 'rgba(244,63,94,0.55)',  icon: '✕', color: '#fb7185' },
            info:    { border: 'rgba(56,189,248,0.55)', icon: 'i', color: '#38bdf8' }
        }[kind] || { border: 'rgba(56,189,248,0.55)', icon: 'i', color: '#38bdf8' };

        let stack = document.getElementById('cn-toast-stack');
        if (!stack) {
            stack = document.createElement('div');
            stack.id = 'cn-toast-stack';
            stack.style.cssText = 'position:fixed;top:16px;right:16px;z-index:999999;display:flex;flex-direction:column;gap:8px;max-width:400px;pointer-events:none;';
            document.body.appendChild(stack);
        }
        const item = document.createElement('div');
        item.style.cssText = `pointer-events:auto;display:flex;align-items:flex-start;gap:10px;padding:11px 14px;border-radius:12px;border:1px solid ${palette.border};background:rgba(15,23,42,0.96);color:#f8fafc;font:600 13px/1.45 system-ui,-apple-system,sans-serif;box-shadow:0 14px 34px rgba(0,0,0,0.5);backdrop-filter:blur(12px);white-space:pre-line;transition:opacity .2s ease;`;
        item.innerHTML = `<span style="width:20px;height:20px;border-radius:999px;background:${palette.color}22;border:1px solid ${palette.border};color:${palette.color};display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:900;flex-shrink:0;margin-top:1px;">${palette.icon}</span><span style="flex:1;"></span><button type="button" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:14px;line-height:1;padding:0 2px;">&times;</button>`;
        item.children[1].textContent = text;
        item.children[2].onclick = () => item.remove();
        stack.appendChild(item);
        setTimeout(() => { item.style.opacity = '0'; setTimeout(() => item.remove(), 220); }, 3800);
    }

    window.cnNotify = showInPageNotice;
    window.alert = function (msg) {
        showInPageNotice(msg);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadStoreBrand);
    } else {
        loadStoreBrand();
    }
})();
