{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "b74f216ca5834c679dde9412c6a61ae23fe46873c9ed9b6483209fe57325c3e54b287e89a0064420fee6d3acc000c15fb36b7f60fe0a8a5631bf98348a9e0e1a",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}