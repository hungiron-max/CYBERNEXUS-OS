{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "804207137f1560fe493be987c2ebb094576f792b5ed41189479cf9d796d17d078a0ea23ae479f9bb7fe7da32314b6599afacfc7e56f7dd4be48b1d05dc0532fb",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "88d331ab72d0e54ad631215481c3e1b0344bfe6f47bafdb655d9b2663206b959",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}