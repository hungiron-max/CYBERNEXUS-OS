{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "c534427675d6aaa4c341c6d8556082b99d81d1a1d46449f5431008eef05e1d56d14cec5541361b5b18ba2b53969bf9649a2e129260c63d97c530eab95cb9d06e",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}