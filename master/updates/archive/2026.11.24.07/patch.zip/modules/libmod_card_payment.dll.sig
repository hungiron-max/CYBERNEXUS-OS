{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "2e28d719852df2810b3a8b97b79046fb5e71edbad1f3389c6e77a8c014d8a5d3055e953751daa67f85724bf0ddfb72d996bfe08c01f9fe0fa1b50d8fbf8adfb1",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}