{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "d8074e452c78056eaf722a837d4aa1b4693ce1d4a79675e7a7629944708c9ad3158e9fd7b9e3f33865be8d6261131a6884ff2fe488da673083a8dac61f615efa",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}