{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "3d0df0abb9874538ef30d5e7523a3267fb3fd3bdd625c536734853bb9d2ccdff70ba73da0703208e23f7df70a952f60115891ff7daf0900864182aefa174ba36",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "b45f72a0c89e8cd07ea1116134bf7cd2da59d92913de61185e8a20685107bb65",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}