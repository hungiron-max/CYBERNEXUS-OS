{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "2624a86611e46d9bd3a8354091d48b73a9a355d0bab35090776063fea49c951d9cd2b7706194a0f7ee5043f0b85f8acf327364494deea35c76b44cdf4a0ff0a8",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "d0b12d214e47c669eb580f7d7a7d8ba84036aa234f0db4d5e33a23170ce248a0",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}