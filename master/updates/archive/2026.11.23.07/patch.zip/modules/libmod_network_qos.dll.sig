{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "b427fc432512c433353243f564f134ddf92f8a007f668a072925dce2295029de033bee6ce9dfe2cbdf8edc3369312e34ae45a82f04440ed9d811565d593f1861",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "e2aa8db5d3e9b749e5f3e278525688a4241fd54c06bcf18c96f18302c79b7beb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}