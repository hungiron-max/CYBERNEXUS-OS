{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "0a113ba7c510817f4bf7d0c6fa60fd62940efbcdfc0fbf4665f2d85490e71c42d11774406405ca2136ffe6764b83e0cc553acab752af94344a184776622b0e12",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "97be79a40534d763c633e084a586b81c06a224821333335f932b28e6102dbce5",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}