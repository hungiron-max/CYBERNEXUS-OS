{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "2a8a929024cc8b31a8221c051fdae9c43854adbafaf80dfb8de0d917ade8736780c0561c82c2ebf3deb5885069e9cb4c6f7fea223a0b349a045225c82ae30d78",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}