{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "19c8bc62c23667b068449add730ea6efde04f0711ad6b5431db0c123870b7d55880e0d02baaabf652b08fe9232e4585b46eeae6b40acc60fb795e39e7bccd267",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "4f83c975976c253103647c9fd2553b396439609675c18795a1ad437cff2a82d6",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}