{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "ef9ab7657c1d54e01778bc9e287f73ec64681bd04c9af7847f5937c1da2abb4ab9628923a078c7bb977eda62c2ffe36d841389ff2351619a455dfa2b61728ac3",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}