{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "14e9f793f0dfdc44f36ac3d0639ba143f517e1a231e1ec9b2dc65e11c0fc1894a56daa6fd36ed6d489e1ab793655b628a6863d8fcccb1219b0a74ba85ad623d5",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "353c8be0c2d7f83fac486ef7cb3539afd002810d0ef408b2a4579980d7f07344",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}