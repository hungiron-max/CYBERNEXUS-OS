{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "f5337ebf4dc67bfdd0d43c0551b086ca0297ba7f7ebac2bc5d03b6564fde0a70f0f856c110963d35cdd9c1f8f973b9e289fd43c328a2f299fef6ea44675a95c7",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}