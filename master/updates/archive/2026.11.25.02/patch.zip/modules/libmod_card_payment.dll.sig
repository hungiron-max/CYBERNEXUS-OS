{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "af257d3cf5350c72105fd66f0372881c294a1d2456799673263c55afc046251105b042348a5036dc7d4b7f2086bddeec428ef8c60afe735daf1e4b034a84721c",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}