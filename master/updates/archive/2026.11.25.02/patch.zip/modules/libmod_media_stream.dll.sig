{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "4d1b27bab413dfd1f6aeece8dcf2f2af1a1892d3efa3014109c4d42c9d46480a310e56eabf7cee501941bb66367f9b895b4c956fc6c3b6d47c0f35417c2601b6",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}