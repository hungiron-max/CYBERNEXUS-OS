{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "4426b13771732bc89f13f11387e1d5ae937270da4a02b40f49fd42512dbefb968fa626c0c794ff08f83b88ee27afe8d98719e83290d769cf77bf08f72dada71a",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}