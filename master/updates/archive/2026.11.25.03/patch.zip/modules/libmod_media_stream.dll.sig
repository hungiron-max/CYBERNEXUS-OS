{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "8c9cad7b55e9aa58357dbbd1512d0fd0986681584b0ae4dce6825e1f76d7a9a6c42cb40f87906af220ef259b8b26f7726af0444a7ad2e8b9b6d0c7ed739ce3f3",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}