{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "36e95be695a62a06a76dba76bd16107c5c54c073e1f3a945a48a6213e5ccb4c28b67e197211a3d1b427a68942804601b0a27d460d42c6f4c92f9f81163480c04",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}