{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "fd8439405ff2efa901dc566b4069eca9c2d2f7a48da09019282cdde53efda7e1c073c0d0af56ba1bdf33926b5d63bca1ddb201e45623709155e24627064fea2a",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}