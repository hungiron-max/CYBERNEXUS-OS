{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "264d41e182e32dcb135131a6797da98619c2a78f252210b913ffaa6c8fcb96e2d544ce13e9c8a3d4e0b558741d6bb74fcab86bc4d41285d9c0e5d70ac692a57b",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "1489b5702e3cc3b90ba99679fc8787860dbf330cd352c154ff98e1c9d8fdceb2",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}