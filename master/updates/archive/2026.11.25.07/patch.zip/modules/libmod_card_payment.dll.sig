{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "67f961dd1a8dbdbefa3681fb08ec553b57a0ebc746fafe42668c4522200d3da8cb58fb94fe666f2674333b6d62383e89ed6d904182b85e3f01bac6ef1f883f37",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}