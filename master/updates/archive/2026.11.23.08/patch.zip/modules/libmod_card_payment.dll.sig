{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "0852a4da285516bfe6f62ebdc1614f73d0878ce7997e836eda0e503a08f634879ebd85d8f8031deb62060c6c60e5f19d26394a0b63b6093623fbb471451ece65",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}