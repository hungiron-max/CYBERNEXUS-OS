{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "85f14f72f6a9761c82a08341c5575df58d93da24c37d33631f76fbc5ab01520af5504d4c8f3bc37a7799735ef3a912fb06a73098ed0e7f42b6b90d3dd85c1c0b",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "97be79a40534d763c633e084a586b81c06a224821333335f932b28e6102dbce5",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}