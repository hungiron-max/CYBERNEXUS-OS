{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "c2af54a374b8a4d2ae9d04ad6a4c98e0a1e2af37f37dfbb817ed24a1aefc359825a7096eb9df1f52e7305c5be6fed6736a2e86eb5ce21dd0df0ae217f16db27d",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "e2aa8db5d3e9b749e5f3e278525688a4241fd54c06bcf18c96f18302c79b7beb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}