(function () {
    const FALLBACK_BRAND = {
        store_name: 'CyberNexus POS',
        store_wifi: '',
        store_wifi_ssid: '',
        store_hotline: '',
        store_address: ''
    };

    window.CN_STORE_BRAND = Object.assign({}, FALLBACK_BRAND);

    function applyStoreBrand(brand) {
        const name = (brand && brand.store_name) ? String(brand.store_name).trim() : FALLBACK_BRAND.store_name;
        const wifiSsid = (brand && (brand.store_wifi_ssid || brand.store_wifi)) ? String(brand.store_wifi_ssid || brand.store_wifi).trim() : '';
        window.CN_STORE_BRAND = Object.assign({}, FALLBACK_BRAND, brand, { store_name: name });

        document.querySelectorAll('[data-store-name]').forEach(el => {
            el.textContent = name;
        });
        document.querySelectorAll('[data-store-wifi]').forEach(el => {
            if (wifiSsid) el.textContent = wifiSsid;
        });

        const titleEl = document.querySelector('title');
        if (titleEl) {
            const suffix = titleEl.getAttribute('data-title-suffix');
            if (suffix) {
                document.title = `${name} - ${suffix}`;
            } else if (/CyberNexus POS|GÓC PHỐ|Góc Phố/i.test(document.title)) {
                document.title = document.title.replace(/GÓC PHỐ COFFEE & TEA|Góc Phố Coffee & Tea|CyberNexus POS/gi, name);
            }
        }

        const standeeTitle = document.getElementById('standee-store-title');
        if (standeeTitle) standeeTitle.textContent = name.toUpperCase();
    }

    window.getStoreBrandName = function () {
        return (window.CN_STORE_BRAND && window.CN_STORE_BRAND.store_name) || FALLBACK_BRAND.store_name;
    };

    window.applyStoreBrand = applyStoreBrand;

    function applyStoreTheme(theme) {
        if (!theme || typeof theme !== 'object' || (!theme.dark && !theme.light && !theme.primary)) {
            document.documentElement.removeAttribute('data-custom-theme');
            return;
        }
        const r = document.documentElement;
        const d = theme.dark || theme;
        const l = theme.light || {};
        r.setAttribute('data-custom-theme', '1');
        r.style.setProperty('--cn-primary', d.primary || '#38bdf8');
        r.style.setProperty('--cn-accent', d.accent || '#8b5cf6');
        r.style.setProperty('--cn-bg-start', d.bg_start || '#070d1b');
        r.style.setProperty('--cn-bg-end', d.bg_end || '#0f172a');
        r.style.setProperty('--cn-card-bg', d.card_bg || 'rgba(15, 23, 42, 0.78)');
        r.style.setProperty('--cn-card-border', d.card_border || 'rgba(56, 189, 248, 0.25)');
        r.style.setProperty('--cn-text', d.text || '#f1f5f9');
        if (l.primary) r.style.setProperty('--cn-light-primary', l.primary);
        if (l.accent) r.style.setProperty('--cn-light-accent', l.accent);
        if (l.bg_start) r.style.setProperty('--cn-light-bg-start', l.bg_start);
        if (l.bg_end) r.style.setProperty('--cn-light-bg-end', l.bg_end);
        if (l.card_bg) r.style.setProperty('--cn-light-card-bg', l.card_bg);
        if (l.card_border) r.style.setProperty('--cn-light-card-border', l.card_border);
        if (l.text) r.style.setProperty('--cn-light-text', l.text);
        r.style.setProperty('--cn-radius', (Number(theme.radius) || 16) + 'px');
        r.style.setProperty('--cn-blur', (Number(theme.blur) || 16) + 'px');
        if (theme.font) r.style.setProperty('--cn-font', theme.font);
        if (theme.slogan) {
            document.querySelectorAll('[data-store-slogan]').forEach(el => { el.textContent = theme.slogan; });
        }
    }
    window.applyStoreTheme = applyStoreTheme;

    window.addEventListener('message', (ev) => {
        if (ev && ev.data && ev.data.type === 'CN_THEME_PREVIEW') {
            applyStoreTheme(ev.data.theme);
            if (ev.data.store_name) applyStoreBrand({ store_name: ev.data.store_name });
        }
    });

    async function loadStoreBrand() {
        try {
            const cached = sessionStorage.getItem('cn_store_brand');
            if (cached) {
                applyStoreBrand(JSON.parse(cached));
            }
        } catch (e) {}

        try {
            const res = await fetch('/api/settings.php', { cache: 'no-store' });
            const json = await res.json();
            const d = (json && json.data) ? json.data : json;
            if (d && d.ota_applied_version) {
                const page = (window.location.pathname || '').toLowerCase();
                const isPublicPage = page.endsWith('/login.html') || page.endsWith('/customer.html') || page.endsWith('/wifi.html');
                const prevOta = localStorage.getItem('cnx_session_ota_ver');
                if (!isPublicPage && localStorage.getItem('pos_token')) {
                    if (prevOta && prevOta !== d.ota_applied_version) {
                        localStorage.removeItem('pos_token');
                        localStorage.removeItem('pos_user');
                        localStorage.setItem('cnx_session_ota_ver', d.ota_applied_version);
                        window.location.href = 'login.html?reason=updated';
                        return;
                    }
                    if (!prevOta) localStorage.setItem('cnx_session_ota_ver', d.ota_applied_version);
                } else if (isPublicPage) {
                    localStorage.setItem('cnx_session_ota_ver', d.ota_applied_version);
                }
            }
            if (d && d.theme_json) {
                try {
                    const tObj = typeof d.theme_json === 'string' ? JSON.parse(d.theme_json) : d.theme_json;
                    applyStoreTheme(tObj);
                    sessionStorage.setItem('cn_store_theme', JSON.stringify(tObj));
                } catch (e) {}
            } else {
                try {
                    const cachedTheme = sessionStorage.getItem('cn_store_theme');
                    if (cachedTheme) applyStoreTheme(JSON.parse(cachedTheme));
                } catch (e) {}
            }
            if (d && d.store_name) {
                applyStoreBrand(d);
                try {
                    sessionStorage.setItem('cn_store_brand', JSON.stringify({
                        store_name: d.store_name,
                        store_wifi: d.store_wifi || '',
                        store_wifi_ssid: d.store_wifi_ssid || '',
                        store_hotline: d.store_hotline || '',
                        store_address: d.store_address || ''
                    }));
                } catch (e) {}
            }
        } catch (e) {}

        try {
            const lRes = await fetch('/api/license.php?action=status', { cache: 'no-store' });
            const lJson = await lRes.json();
            if (lJson && lJson.success && lJson.data) {
                const mods = Array.isArray(lJson.data.modules) ? lJson.data.modules : [];
                const blocked = Array.isArray(lJson.data.blocked_modules) ? lJson.data.blocked_modules : [];
                const mediaAllowed = (mods.includes('mod_media_stream') || mods.includes('media_stream'))
                    && !blocked.includes('mod_media_stream') && !blocked.includes('media_stream');
                if (!mediaAllowed) {
                    ['pos-jukebox-pill', 'admin-jukebox-pill', 'customer-jukebox-bar'].forEach(id => {
                        const el = document.getElementById(id);
                        if (el) el.style.display = 'none';
                    });
                }
            }
        } catch (e) {}
    }

    function showInPageNotice(msg) {
        let n = document.getElementById('cn-fs-notice');
        if (!n) {
            n = document.createElement('div');
            n.id = 'cn-fs-notice';
            n.style.cssText = 'position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:99999;max-width:440px;padding:11px 18px;border-radius:12px;border:1px solid rgba(56,189,248,0.45);background:rgba(15,23,42,0.96);color:#f8fafc;font:600 13px system-ui,sans-serif;box-shadow:0 16px 40px rgba(0,0,0,0.55);text-align:center;';
            document.body.appendChild(n);
        }
        n.textContent = String(msg || '');
        n.style.display = 'block';
        clearTimeout(showInPageNotice._t);
        showInPageNotice._t = setTimeout(() => { n.style.display = 'none'; }, 3200);
    }

    const _origAlert = window.alert ? window.alert.bind(window) : null;
    window.alert = function (msg) {
        if (document.fullscreenElement) {
            showInPageNotice(msg);
            return;
        }
        if (_origAlert) return _origAlert(msg);
    };

    function initFullscreenButton() {
        if (document.getElementById('cn-fs-toggle')) return;
        const btn = document.createElement('button');
        btn.id = 'cn-fs-toggle';
        btn.type = 'button';
        btn.title = 'Bật/Tắt Toàn Màn Hình (ẩn thanh trình duyệt & taskbar)';
        btn.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:45;display:inline-flex;align-items:center;gap:6px;padding:7px 11px;border-radius:10px;border:1px solid rgba(148,163,184,0.45);background:rgba(15,23,42,0.85);color:#e2e8f0;font:600 11.5px system-ui,sans-serif;cursor:pointer;backdrop-filter:blur(10px);box-shadow:0 6px 18px rgba(0,0,0,0.35);';
        const syncIcon = () => {
            const fs = Boolean(document.fullscreenElement);
            btn.innerHTML = fs ? '<span>✕</span><span>Thoát Full</span>' : '<span>⛶</span><span>Toàn màn hình</span>';
        };
        btn.onclick = () => {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen?.().catch(() => {});
            } else {
                document.exitFullscreen?.().catch(() => {});
            }
        };
        document.addEventListener('fullscreenchange', syncIcon);
        syncIcon();
        document.body.appendChild(btn);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => { loadStoreBrand(); initFullscreenButton(); });
    } else {
        loadStoreBrand();
        initFullscreenButton();
    }
})();
