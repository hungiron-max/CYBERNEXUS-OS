{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "680f140c4b3d7d7de6a4cb8c28efc449e62cc0ce5e9703a74199f17f2abe93dfd8df2efd142f5b9360f7586950a11205dc8defda4d6a12abcbc07ca4d728249d",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "a83a3e42a5d3b6424ce0701527c3a19c95f731de71bbe51ebf3528005dfb9637",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}