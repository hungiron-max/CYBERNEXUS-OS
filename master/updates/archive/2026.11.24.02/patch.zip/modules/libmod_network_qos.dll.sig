{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "d93b5b5492322ed7699c43461d79b7ff105fe163067639ee5e461ce19ec50cd2ad95ee8c1187c5c54455ce3d3775ac037db2e32deee988e13708719aa0f662d6",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "4f83c975976c253103647c9fd2553b396439609675c18795a1ad437cff2a82d6",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}