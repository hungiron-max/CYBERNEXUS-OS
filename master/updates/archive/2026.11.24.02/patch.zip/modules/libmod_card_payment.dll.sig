{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "0508cf05b74093967664a4e681f27b4cae2ef71b1a5eb19c4dd16a0680abe4832d4abe9c8472a586bda1dceb309b2b5805b5feddd5283ac76181abe22b4d5a86",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}