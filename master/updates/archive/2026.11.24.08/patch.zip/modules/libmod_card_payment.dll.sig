{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "867e97dba4d65aeb8fe1863d7cd0d500272936f9b874563340f66e0b14b691b2dd0a3d9141378143f134fe203894e9cbc591d3622365b7c72601304674fe19bc",
  "file": "libmod_card_payment.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "386213f7b75f18f4eb7f030a918117fd100df4a88148beda56b1714f0c2a70cb",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}