{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "300b14835fffb84efb0a0976dbf22d84ee50f0053d80d41605abc8e3053485720b2cca74c7afcafed6a47fc6dd13cafebcfb6ba4b8a9bdbd36d53d3e43714f48",
  "file": "libmod_network_qos.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "c1d963791a0e939af1e950b7e8560b730362a0b5751f4fca207dbfce0642df33",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}