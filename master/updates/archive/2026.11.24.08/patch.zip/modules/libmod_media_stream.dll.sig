{
  "algorithm": "ECDSA-P256-SHA256",
  "ecdsa_sig": "4fb8052d8fba4c551daa0ab8ba49bc3ec091ef83cc699a9cba89dc7c3caa98c7976bd1c0c09d23b9c6d11e9185db71dd00c2f131acdfbce37f5f734225c849ac",
  "file": "libmod_media_stream.dll",
  "key_fingerprint": "ECDSA-P256-EF18CC703F77B217",
  "sha256": "b45f72a0c89e8cd07ea1116134bf7cd2da59d92913de61185e8a20685107bb65",
  "signed_by": "CyberNexus-SuperAdmin",
  "version": 2
}