/**
 * CyberNexus OS — Offline Runtime i18n Engine (100% LAN/Local, Zero CDN)
 */
(function (global) {
    'use strict';

    const STORAGE_KEY = 'cnx_lang';
    const SUPPORTED = ['vi', 'en'];
    const CORE_FALLBACK = {
        vi: {
            common: {
                confirm_title: 'Xác nhận thao tác',
                prompt_title: 'Nhập thông tin',
                ok: 'Đồng ý',
                confirm: 'Xác nhận',
                cancel: 'Hủy bỏ',
                close: 'Đóng',
                sim_warning: 'CHẾ ĐỘ MÔ PHỎNG — CHƯA NỐI THIẾT BỊ THẬT'
            }
        },
        en: {
            common: {
                confirm_title: 'Confirm Action',
                prompt_title: 'Enter Input',
                ok: 'OK',
                confirm: 'Confirm',
                cancel: 'Cancel',
                close: 'Close',
                sim_warning: 'SIMULATION MODE — HARDWARE NOT CONNECTED'
            }
        }
    };

    const dicts = {
        vi: JSON.parse(JSON.stringify(CORE_FALLBACK.vi)),
        en: JSON.parse(JSON.stringify(CORE_FALLBACK.en))
    };
    const loadedLangs = {};

    function detectInitialLang() {
        try {
            const p = new URLSearchParams(global.location ? global.location.search : '');
            const qLang = (p.get('lang') || '').toLowerCase();
            if (SUPPORTED.indexOf(qLang) >= 0) {
                try { localStorage.setItem(STORAGE_KEY, qLang); } catch (e) {}
                return qLang;
            }
        } catch (e) {}
        try {
            const saved = (localStorage.getItem(STORAGE_KEY) || '').toLowerCase();
            if (SUPPORTED.indexOf(saved) >= 0) return saved;
        } catch (e) {}
        return 'vi';
    }

    let currentLang = detectInitialLang();

    function deepGet(obj, path) {
        if (!obj || !path) return undefined;
        const parts = String(path).split('.');
        let cur = obj;
        for (let i = 0; i < parts.length; i++) {
            if (cur === null || cur === undefined || typeof cur !== 'object') return undefined;
            cur = cur[parts[i]];
        }
        return typeof cur === 'string' ? cur : undefined;
    }

    function formatVars(str, vars) {
        if (!vars || typeof vars !== 'object') return str;
        return str.replace(/\{([a-zA-Z0-9_]+)\}/g, function (_, k) {
            return Object.prototype.hasOwnProperty.call(vars, k) ? String(vars[k]) : `{${k}}`;
        });
    }

    function mergeDict(lang, incoming) {
        if (!incoming || typeof incoming !== 'object') return;
        const dst = dicts[lang] || (dicts[lang] = {});
        Object.keys(incoming).forEach(function (ns) {
            if (incoming[ns] && typeof incoming[ns] === 'object' && !Array.isArray(incoming[ns])) {
                dst[ns] = Object.assign({}, dst[ns] || {}, incoming[ns]);
            } else {
                dst[ns] = incoming[ns];
            }
        });
    }

    async function ensureLoaded(lang) {
        if (SUPPORTED.indexOf(lang) < 0) return false;
        if (loadedLangs[lang]) return true;
        if (global.location && global.location.protocol === 'file:') return false;
        try {
            const res = await fetch('/locales/' + lang + '.json?v=20261121', { cache: 'no-store' });
            if (res.ok) {
                const json = await res.json();
                mergeDict(lang, json);
                loadedLangs[lang] = true;
                return true;
            }
        } catch (e) {}
        return false;
    }

    function t(key, varsOrFallback, fallback) {
        let vars = null;
        let fb = '';
        if (typeof varsOrFallback === 'string') {
            fb = varsOrFallback;
        } else if (varsOrFallback && typeof varsOrFallback === 'object') {
            vars = varsOrFallback;
            fb = typeof fallback === 'string' ? fallback : '';
        } else if (typeof fallback === 'string') {
            fb = fallback;
        }

        let val = deepGet(dicts[currentLang], key);
        if (val === undefined && currentLang !== 'vi') {
            val = deepGet(dicts.vi, key);
        }
        if (val === undefined) {
            val = fb || key;
        }
        return formatVars(val, vars);
    }

    function updateSwitcherUi() {
        if (!global.document) return;
        global.document.documentElement.lang = currentLang;
        global.document.querySelectorAll('[data-cnx-lang-btn]').forEach(function (btn) {
            const bLang = (btn.getAttribute('data-cnx-lang-btn') || '').toLowerCase();
            const active = bLang === currentLang;
            btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            btn.classList.toggle('bg-sky-500', active);
            btn.classList.toggle('text-slate-950', active);
            btn.classList.toggle('shadow-sm', active);
            btn.classList.toggle('text-slate-300', !active);
            btn.classList.toggle('hover:text-white', !active);
        });
    }

    function applyDom(root) {
        const scope = root || global.document;
        if (!scope || !scope.querySelectorAll) return;

        scope.querySelectorAll('[data-i18n]').forEach(function (el) {
            const key = el.getAttribute('data-i18n');
            if (!key) return;
            if (!el.hasAttribute('data-i18n-default')) {
                el.setAttribute('data-i18n-default', el.textContent);
            }
            const defTxt = el.getAttribute('data-i18n-default') || '';
            const resolved = deepGet(dicts[currentLang], key);
            el.textContent = resolved !== undefined ? resolved : (currentLang === 'vi' ? defTxt : (deepGet(dicts.vi, key) || defTxt));
        });

        scope.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
            const key = el.getAttribute('data-i18n-placeholder');
            if (!key) return;
            if (!el.hasAttribute('data-i18n-ph-default')) {
                el.setAttribute('data-i18n-ph-default', el.getAttribute('placeholder') || '');
            }
            const defTxt = el.getAttribute('data-i18n-ph-default') || '';
            const resolved = deepGet(dicts[currentLang], key);
            el.setAttribute('placeholder', resolved !== undefined ? resolved : (currentLang === 'vi' ? defTxt : (deepGet(dicts.vi, key) || defTxt)));
        });

        scope.querySelectorAll('[data-i18n-title]').forEach(function (el) {
            const key = el.getAttribute('data-i18n-title');
            if (!key) return;
            if (!el.hasAttribute('data-i18n-title-default')) {
                el.setAttribute('data-i18n-title-default', el.getAttribute('title') || '');
            }
            const defTxt = el.getAttribute('data-i18n-title-default') || '';
            const resolved = deepGet(dicts[currentLang], key);
            el.setAttribute('title', resolved !== undefined ? resolved : (currentLang === 'vi' ? defTxt : (deepGet(dicts.vi, key) || defTxt)));
        });

        updateSwitcherUi();
    }

    async function setLang(lang) {
        const next = String(lang || '').toLowerCase();
        if (SUPPORTED.indexOf(next) < 0) return currentLang;
        currentLang = next;
        try { localStorage.setItem(STORAGE_KEY, currentLang); } catch (e) {}
        await ensureLoaded(currentLang);
        applyDom();
        try {
            global.dispatchEvent(new CustomEvent('cnx:lang-changed', { detail: { lang: currentLang } }));
        } catch (e) {}
        return currentLang;
    }

    const readyPromise = Promise.all([ensureLoaded('vi'), ensureLoaded(currentLang)]).then(function () {
        applyDom();
        try {
            global.dispatchEvent(new CustomEvent('cnx:i18n-ready', { detail: { lang: currentLang } }));
        } catch (e) {}
        return currentLang;
    });

    if (global.document) {
        if (global.document.readyState === 'loading') {
            global.document.addEventListener('DOMContentLoaded', function () {
                applyDom();
            });
        } else {
            applyDom();
        }
    }

    global.CNX_I18N = {
        getLang: function () { return currentLang; },
        setLang: setLang,
        t: t,
        applyDom: applyDom,
        ready: readyPromise
    };
    global.cnxT = t;
})(window);
